﻿
Thank you for using Select.Pdf Html To Pdf Converter for .NET - Community Edition.

Online demo C#: http://selectpdf.com/html-to-pdf/demo/
Online demo Vb.Net: http://selectpdf.com/html-to-pdf/demo-vb/
Online documentation: http://selectpdf.com/html-to-pdf/docs/


With Select.Pdf is very easy to convert any web page to a pdf document. The code is as simple as this:

            SelectPdf.HtmlToPdf converter = new SelectPdf.HtmlToPdf();
            SelectPdf.PdfDocument doc = converter.ConvertUrl("http://selectpdf.com");
            doc.Save("test.pdf");
            doc.Close();



For complete product information, take a look at http://selectpdf.com.
For support, contact us at support@selectpdf.com.
